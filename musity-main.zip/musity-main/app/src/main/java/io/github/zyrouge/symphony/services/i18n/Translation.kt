package io.github.zyrouge.symphony.services.i18n

import org.json.JSONObject

class Translation(json: JSONObject) : _Translation(json)
