plugins {
    alias(libs.plugins.android.app) apply false
    alias(libs.plugins.android.kotlin) apply false
}